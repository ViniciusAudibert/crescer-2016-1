﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LojaNinja.Domino.Test
{
    [TestClass]
    public class PedidoTest
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
