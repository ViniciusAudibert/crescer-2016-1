﻿namespace LojaNinja.Dominio
{
    public enum TipoPagamento
    {
        Amex = 1,
        Diners = 2,
        Visa = 3,
        Mastercard = 4
    }
}